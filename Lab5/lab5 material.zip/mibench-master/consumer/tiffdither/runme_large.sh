#!/bin/sh
../tiff-v3.5.4/tools/tiffdither -c g4 ../tiff-data/largebw.tif output_largedither.tif
