#!/bin/sh
../tiff-v3.5.4/tools/tiff2rgba -c none ../tiff-data/small.tif output_smallrgba.tif
