#!/bin/sh
../tiff-v3.5.4/tools/tiff2bw ../tiff-data/small.tif output_smallbw.tif
