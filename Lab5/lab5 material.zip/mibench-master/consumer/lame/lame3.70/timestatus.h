#ifndef TIMESTATUS_H_INCLUDED
#define TIMESTATUS_H_INCLUDED


void timestatus(int samp_rate,long frameNum,long totalframes, int framesize);


#endif
