#!/bin/sh
mad-0.14.2b/madplay --time=30 --output=wave:output_large.wav -v large.mp3
