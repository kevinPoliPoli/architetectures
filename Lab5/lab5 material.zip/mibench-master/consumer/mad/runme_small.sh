#!/bin/sh
mad-0.14.2b/madplay --time=4 --output=wave:output_small.wav -v small.mp3
