#!/bin/sh
../tiff-v3.5.4/tools/tiffmedian ../tiff-data/small.tif output_smallmedian.tif
